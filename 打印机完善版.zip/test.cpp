#include<windows.h>
#include "type.h"

int main(){
	Sleep(3000);
	symbol('?');
}
