#include<windows.h>


void symbol(char c){
	switch(c){
		case '.' :
			keybd_event(VK_DECIMAL,0,0,0);
			break;
		case '!' :
			keybd_event(VK_SHIFT,0,0,0);
	        keybd_event('1',0,0,0);
	        keybd_event(VK_SHIFT,0,KEYEVENTF_KEYUP,0);
	        break;
	    case ':' :
	    	keybd_event(VK_SHIFT,0,0,0);
	        keybd_event(0xBA,0,0,0);
	        keybd_event(VK_SHIFT,0,KEYEVENTF_KEYUP,0);
	        break;
	    case '?' :
		    keybd_event(VK_SHIFT,0,0,0);
	        keybd_event(0xBF,0,0,0);
	        keybd_event(VK_SHIFT,0,KEYEVENTF_KEYUP,0);
	        break;
	    case '"' :
	    	keybd_event(VK_SHIFT,0,0,0);
	        keybd_event(0xDE,0,0,0);
	        keybd_event(VK_SHIFT,0,KEYEVENTF_KEYUP,0);
	        break;
	    case '(' :
	    	keybd_event(VK_SHIFT,0,0,0);
	        keybd_event('9',0,0,0);
	        keybd_event(VK_SHIFT,0,KEYEVENTF_KEYUP,0);
	        break;
	    case ')' :
			keybd_event(VK_SHIFT,0,0,0);
	        keybd_event('9',0,0,0);
	        keybd_event(VK_SHIFT,0,KEYEVENTF_KEYUP,0);
	        break;
	    case '\'' :
	    	keybd_event(0xDE,0,0,0);
	    	break;
	    case ',' :
	    	keybd_event(0xBC,0,0,0);
	    	break;
	    case '/' :
	    	keybd_event(0xBF,0,0,0);
	    	break;
	    case ';' :
	    	keybd_event(0xBA,0,0,0);
	    	break;
	    case ' ' :
	    	keybd_event(VK_SPACE,0,0,0);
	        break;
	    case '@' :
		    keybd_event(VK_RETURN,0,0,0);
		    break;
		case '-' :
			keybd_event(0xBD,0,0,0);
			break;
	}
	if(c >= 48 && c <= 57){
		keybd_event(c,0,0,0);
	}
	if(c >= 97 && c <= 122){
		keybd_event(c-('a'-'A'),0,0,0);
	}
	if(c >= 65 && c <= 90){
		keybd_event(VK_SHIFT,0,0,0);
	    keybd_event(c,0,0,0);
	    keybd_event(VK_SHIFT,0,KEYEVENTF_KEYUP,0);
	}
}

