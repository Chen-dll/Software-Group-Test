#include <iostream>
#include <cstdio>
#include <stdio.h>
#include <cstring>
using namespace std;
char n[100000];
void change(char c)
{   
    if(c == '-'){
    	printf("%s\n","symbol('-');");
	}
    if(c == '@'){
    	printf("%s\n","symbol('@');");
	}
	if(c == '/'){
    	printf("%s\n","symbol('/');");
	}
    if(c == '?'){
    	printf("%s\n","symbol('?');");
	}
    if(c == '('){
    	printf("%s\n","symbol('(');");
	}
    if(c == ')'){
    	printf("%s\n","symbol(')');");
	}
	if(c == '!'){
		printf("%s\n","symbol('!');");
	}//̾��
	if(c == ':'){
        printf("%s\n","symbol(':');");
	} 
	if(c == ' ')
	{
		printf("%s\n","symbol(' ');");
	}//�ո� 
	if(c == '.')
	{
		printf("%s\n","symbol('.');");
	}//��� 
	if(c == ',')
	{
		printf("%s\n","symbol(',');");
	}//���� 
	if(c == 39)
	{
		printf("%s\n","symbol('\');");
	}//���� 
	if(c == '"')
	{
		printf("%s\n","symbol('\"');");
	}//˫�� 
	if(c==';')
	{
		printf("%s\n","symbol(';');");
	}//�ֺ� 
	if(c >= 48 && c <= 57)
	{
		printf("%s%c%s\n","symbol(\'",c,"\');");
	}//���� 
	if(c >= 97 && c <= 122)
	{
		printf("%s%c%s\n","symbol(\'",c,"\');");
	}//Сд��ĸ 
	if(c >= 65 && c <= 90)
	{
		printf("%s%c%s\n","symbol(\'",c,"\');");
	}//��д��ĸ 
}
int main(){
//  freopen("i.txt", "r", stdin);
	freopen("ou.cpp", "w", stdout);
	gets(n);
	int x = strlen(n);
	printf("%s\n","#include <windows.h>");
	printf("%s\n","#include \"type.h\"");
	printf("%s","int main()\n{ \n  Sleep(10000);\n");
	for(int i = 0; i < x; i++)
	{
		change(n[i]);
	}
	printf("%c",'}');
//  fclose(stdin);
	fclose(stdout);
	system("cmd /c gcc ou.cpp -o ou");
	system("load.bat"); 
	system("pause");
}

